﻿namespace YTech.SIS.GJCell.Web.Mvc.Controllers
{
    using System.Web.Mvc;

    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Dashboard()
        {
            return View();
        }

        public ActionResult UnderConstruction()
        {
            return View();
        }
        
    }
}
