﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;

namespace YTech.SIS.GJCell.Web.Mvc.Controllers.ViewModels
{
    public class RequestWOSPartViewModel
    {
        [DisplayName("SPartWOId")]
        public string SPartWOId
        {
            get;
            set;
        }
        [DisplayName("Tanggal")]
        [Required]
        [UIHint("Date")]
        public DateTime? SPartDate
        {
            get;
            set;
        }

        [DisplayName("Spare Part")]
        [UIHint("SPart")]
        [Required]
        public string SPart
        {
            get;
            set;
        }
        [DisplayName("Jumlah")]
        [Required]
        public decimal SPartQty
        {
            get;
            set;
        }
        [DisplayName("Harga")]
        [Required]
        public decimal SPartPrice
        {
            get;
            set;
        }
        [DisplayName("Total")]
        [Required]
        public decimal SPartTotal
        {
            get;
            set;
        }
    }
}